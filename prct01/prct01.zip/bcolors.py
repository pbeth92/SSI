class Bcolors:
    azul = '\033[94m'
    verde = '\033[92m'
    amarillo = '\033[93m'
    rojo = '\033[91m'
    end = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
